import Vue from 'vue'
import Router from 'vue-router'
const Inicio = () =>
    import ('./components/Inicio')

Vue.use(Router)

export default new Router({
    mode: 'history',
    routes: [{
            path: '/',
            name: 'inicio',
            component: Inicio
        },
        {
            path: '/busqueda',
            name: 'busqueda',
            component: () =>
                import ( /* webpackChunkName: "busqueda" */ "./components/search.vue")
        },
        {
            path: '/ventas',
            name: 'ventas',
            component: () =>
                import ( /* webpackChunkName: "busqueda" */ "./components/sales.vue")
        },
        {
            path: '/total',
            name: 'total',
            component: () =>
                import ( /* webpackChunkName: "busqueda" */ "./components/total.vue")
        },
        {
            path: '/*',
            name: 'notFound',
            component: () =>
                import ( /* webpackChunkName: "busqueda" */ "./components/notFound.vue")
        },
    ]
})