<template>
<div>
    <h2>{{titleTotalStock}}</h2>
    <list :games="availableGames" :hasButton="true" @sell-product="sellProduct"></list>
</div>
</template>

<script>
import List from "@/components/List"; //@ = src
import {
    mapGetters,
    mapActions
} from 'vuex'
export default {
    computed: {
        ...mapGetters(['availableGames']),

        titleTotalStock() {
            return `Cantidad de juegos con Stock: ${this.availableGames.length}`
        }
    },
    components: {
        List
    },
    methods: {
        ...mapActions(['processSale']),
        sellProduct(payLoad) {
            // eslint-disable-next-line
            this.processSale(payLoad.game);
        }

    }
}
</script>

<style>

</style>
