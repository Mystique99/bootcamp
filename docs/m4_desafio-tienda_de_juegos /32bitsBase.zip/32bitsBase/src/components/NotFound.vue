<template>
  <h1>La página no esta disponible</h1>

</template>

<script>
export default {

}
</script>

<style>

</style>